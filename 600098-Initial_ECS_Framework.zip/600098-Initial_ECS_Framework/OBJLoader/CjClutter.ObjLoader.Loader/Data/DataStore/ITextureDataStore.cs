using ObjLoader.Loader.Data.VertexData;

namespace ObjLoader.Loader.Data.DataStore
{
    public interface ITextureDataStore
    {
        void AddTexture(Texture texture);
    }
}