namespace ObjLoader.Loader.Data.DataStore
{
    public interface IGroupDataStore
    {
        void PushGroup(string groupName);
    }
}