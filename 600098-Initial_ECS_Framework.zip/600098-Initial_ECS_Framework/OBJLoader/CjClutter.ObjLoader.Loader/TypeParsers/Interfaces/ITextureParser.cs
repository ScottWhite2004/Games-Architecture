namespace ObjLoader.Loader.TypeParsers.Interfaces
{
    public interface ITextureParser : ITypeParser
    {
    }
}