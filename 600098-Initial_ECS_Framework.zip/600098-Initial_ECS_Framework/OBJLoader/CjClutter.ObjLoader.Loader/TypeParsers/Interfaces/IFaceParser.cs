namespace ObjLoader.Loader.TypeParsers.Interfaces
{
    public interface IFaceParser : ITypeParser
    {
    }
}