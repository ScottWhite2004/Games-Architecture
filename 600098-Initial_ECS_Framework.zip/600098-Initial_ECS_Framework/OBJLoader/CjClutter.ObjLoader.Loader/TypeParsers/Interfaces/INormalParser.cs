namespace ObjLoader.Loader.TypeParsers.Interfaces
{
    public interface INormalParser : ITypeParser
    {
    }
}